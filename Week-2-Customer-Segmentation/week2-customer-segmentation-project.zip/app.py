"""Optional Streamlit app for predicting a customer's K-means segment."""

from pathlib import Path

import joblib
import pandas as pd
import streamlit as st


MODEL_PATH = Path(__file__).resolve().parent / "reports" / "model_bundle.joblib"

st.set_page_config(page_title="Customer Segmentation", page_icon="📊")
st.title("Customer Segmentation")
st.write("Enter customer details to see which K-means cluster is closest.")

if not MODEL_PATH.exists():
    st.error("Model not found. Run `python src/analyze.py` before starting the app.")
    st.stop()

bundle = joblib.load(MODEL_PATH)
model = bundle["model"]
scaler = bundle["scaler"]
features = bundle["features"]

with st.form("customer_details"):
    age = st.number_input("Age", min_value=18, max_value=100, value=35)
    income = st.number_input("Annual income", min_value=0, max_value=1_000_000, value=50_000)
    spending = st.number_input("Total product spending", min_value=0, max_value=100_000, value=500)
    web_purchases = st.number_input("Web purchases", min_value=0, max_value=100, value=5)
    store_purchases = st.number_input("Store purchases", min_value=0, max_value=100, value=5)
    web_visits = st.number_input("Web visits per month", min_value=0, max_value=100, value=5)
    recency = st.number_input("Days since last purchase", min_value=0, max_value=365, value=30)
    submitted = st.form_submit_button("Predict segment")

if submitted:
    values = [[age, income, spending, web_purchases, store_purchases, web_visits, recency]]
    customer = pd.DataFrame(values, columns=features)
    prediction = int(model.predict(scaler.transform(customer))[0])
    st.success(f"Predicted cluster: {prediction}")
    st.caption("Use reports/segment_profiles.csv to interpret this cluster's average characteristics.")
