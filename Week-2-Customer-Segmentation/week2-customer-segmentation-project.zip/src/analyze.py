"""Clean customer data, fit K-means segments, and save reviewable outputs."""

from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler


PROJECT_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_DIR / "data" / "customer_segmentation.csv"
REPORTS_DIR = PROJECT_DIR / "reports"
REFERENCE_YEAR = 2014
N_CLUSTERS = 6
FEATURES = [
    "Age",
    "Income",
    "Total_Spending",
    "NumWebPurchases",
    "NumStorePurchases",
    "NumWebVisitsMonth",
    "Recency",
]
SPENDING_COLUMNS = [
    "MntWines",
    "MntFruits",
    "MntMeatProducts",
    "MntFishProducts",
    "MntSweetProducts",
    "MntGoldProds",
]


def prepare_data(path: Path = DATA_PATH) -> tuple[pd.DataFrame, dict[str, int]]:
    """Load the CSV, remove unusable rows, and create interpretable features."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Download it and save it as "
            "data/customer_segmentation.csv."
        )

    raw = pd.read_csv(path)
    original_rows = len(raw)
    missing_income = int(raw["Income"].isna().sum())
    duplicate_ids = int(raw["ID"].duplicated().sum())
    data = raw.drop_duplicates(subset="ID").dropna(subset=["Income"]).copy()

    data["Age"] = REFERENCE_YEAR - data["Year_Birth"]
    invalid_age = int((~data["Age"].between(18, 100)).sum())
    data = data[data["Age"].between(18, 100)].copy()
    data["Total_Children"] = data["Kidhome"] + data["Teenhome"]
    data["Total_Spending"] = data[SPENDING_COLUMNS].sum(axis=1)
    data["Dt_Customer"] = pd.to_datetime(
        data["Dt_Customer"], format="%d-%m-%Y", errors="coerce"
    )
    data["Tenure_Days"] = (data["Dt_Customer"].max() - data["Dt_Customer"]).dt.days

    audit = {
        "source_rows": original_rows,
        "missing_income_rows_removed": missing_income,
        "duplicate_ids_removed": duplicate_ids,
        "invalid_age_rows_removed": invalid_age,
        "model_rows": len(data),
    }
    return data, audit


def evaluate_cluster_counts(scaled: np.ndarray) -> pd.DataFrame:
    """Calculate inertia and silhouette score for candidate K values."""
    rows = []
    for k in range(2, 11):
        model = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = model.fit_predict(scaled)
        rows.append(
            {
                "k": k,
                "inertia": float(model.inertia_),
                "silhouette_score": float(silhouette_score(scaled, labels)),
            }
        )
    return pd.DataFrame(rows)


def run_analysis(path: Path = DATA_PATH) -> pd.DataFrame:
    """Run the complete analysis and save charts, profiles, and model bundle."""
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    data, audit = prepare_data(path)
    features = data[FEATURES].copy()
    scaler = StandardScaler()
    scaled = scaler.fit_transform(features)

    evaluation = evaluate_cluster_counts(scaled)
    evaluation.to_csv(REPORTS_DIR / "cluster_count_evaluation.csv", index=False)

    model = KMeans(n_clusters=N_CLUSTERS, random_state=42, n_init=10)
    data["Cluster"] = model.fit_predict(scaled)
    profiles = data.groupby("Cluster")[FEATURES].mean().round(2)
    profiles.insert(0, "Customers", data["Cluster"].value_counts().sort_index())
    profiles["Customer_Share"] = (
        data["Cluster"].value_counts(normalize=True).sort_index() * 100
    ).round(1)
    profiles.to_csv(REPORTS_DIR / "segment_profiles.csv")

    # Plot candidate K metrics so the selected cluster count can be reviewed.
    fig, left = plt.subplots(figsize=(9, 5))
    left.plot(evaluation["k"], evaluation["inertia"], marker="o", color="#1976d2")
    left.set_xlabel("Number of clusters (K)")
    left.set_ylabel("Inertia", color="#1976d2")
    right = left.twinx()
    right.plot(
        evaluation["k"], evaluation["silhouette_score"], marker="s", color="#ef6c00"
    )
    right.set_ylabel("Silhouette score", color="#ef6c00")
    plt.title("Choosing the number of customer segments")
    fig.tight_layout()
    fig.savefig(REPORTS_DIR / "elbow_silhouette.png", dpi=160)
    plt.close(fig)

    # PCA is used only to show the seven-dimensional clusters in two dimensions.
    projection = PCA(n_components=2, random_state=42).fit_transform(scaled)
    pca_data = pd.DataFrame(
        {"PC1": projection[:, 0], "PC2": projection[:, 1], "Cluster": data["Cluster"]}
    )
    fig, ax = plt.subplots(figsize=(9, 6))
    sns.scatterplot(
        data=pca_data,
        x="PC1",
        y="PC2",
        hue="Cluster",
        palette="tab10",
        alpha=0.7,
        s=28,
        ax=ax,
    )
    ax.set_title(f"Customer segments shown with PCA (K={N_CLUSTERS})")
    fig.tight_layout()
    fig.savefig(REPORTS_DIR / "customer_segments_pca.png", dpi=160)
    plt.close(fig)

    standardized_profiles = pd.DataFrame(
        scaler.transform(profiles[FEATURES]), columns=FEATURES, index=profiles.index
    )
    fig, ax = plt.subplots(figsize=(11, 5))
    sns.heatmap(
        standardized_profiles,
        cmap="vlag",
        center=0,
        annot=True,
        fmt=".1f",
        linewidths=0.5,
        ax=ax,
    )
    ax.set_title("Segment profiles (standardized feature means)")
    ax.set_ylabel("Cluster number")
    fig.tight_layout()
    fig.savefig(REPORTS_DIR / "segment_profiles.png", dpi=160)
    plt.close(fig)

    joblib.dump(
        {
            "model": model,
            "scaler": scaler,
            "features": FEATURES,
            "n_clusters": N_CLUSTERS,
            "reference_year": REFERENCE_YEAR,
        },
        REPORTS_DIR / "model_bundle.joblib",
    )

    print("Data quality summary:")
    for key, value in audit.items():
        print(f"  {key}: {value}")
    print(f"\nSegment profiles saved to {REPORTS_DIR / 'segment_profiles.csv'}")
    print(f"\nCluster-count evaluation:\n{evaluation.to_string(index=False)}")
    print(f"\nSegment profiles:\n{profiles.to_string()}")
    return profiles


if __name__ == "__main__":
    run_analysis()
